#include <algorithm>
#include <cstdlib>
#include <fcntl.h>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <readline/readline.h>
#include <readline/history.h>
#include <sstream>
#include <string>
#include <sys/wait.h>
#include <unistd.h>
#include <unordered_map>
#include <vector>

namespace fs = std::filesystem;

static std::string trim(const std::string &s) {
  const auto begin = s.find_first_not_of(" \t\r\n");
  if (begin == std::string::npos) {
    return "";
  }
  const auto end = s.find_last_not_of(" \t\r\n");
  return s.substr(begin, end - begin + 1);
}

static std::unordered_map<std::string, std::string> shell_variables;

static std::string getVariableValue(const std::string &name) {
  auto it = shell_variables.find(name);
  if (it != shell_variables.end()) {
    return it->second;
  }
  const char *env = std::getenv(name.c_str());
  if (env) {
    return env;
  }
  return "";
}

static std::vector<std::string> splitCommand(const std::string &input) {
  std::vector<std::string> tokens;
  std::string current;
  size_t i = 0;
  while (i < input.size()) {
    char c = input[i];
    if (c == '\'') {
      // Single-quoted string: everything is literal
      i++;
      while (i < input.size() && input[i] != '\'') {
        current += input[i];
        i++;
      }
      if (i < input.size()) i++;
    } else if (c == '"') {
      // Double-quoted string: backslash escapes only " \ $ ` and newline
      i++;
      while (i < input.size() && input[i] != '"') {
        if (input[i] == '\\' && i + 1 < input.size()) {
          char next = input[i + 1];
          if (next == '"' || next == '\\' || next == '$' || next == '`' || next == '\n') {
            current += next;
            i += 2;
            continue;
          }
        }
        if (input[i] == '$') {
          if (i + 1 < input.size() && input[i + 1] == '{') {
            size_t close = input.find('}', i + 2);
            if (close != std::string::npos) {
              std::string var_name = input.substr(i + 2, close - i - 2);
              current += getVariableValue(var_name);
              i = close + 1;
              continue;
            }
          }
          if (i + 1 < input.size() && (std::isalpha(input[i + 1]) || input[i + 1] == '_')) {
            size_t start = i + 1;
            size_t len = 1;
            while (start + len < input.size() && (std::isalnum(input[start + len]) || input[start + len] == '_')) {
              len++;
            }
            std::string var_name = input.substr(start, len);
            current += getVariableValue(var_name);
            i = start + len;
            continue;
          }
        }
        current += input[i];
        i++;
      }
      if (i < input.size()) i++;
    } else if (c == ' ' || c == '\t') {
      if (!current.empty()) {
        tokens.push_back(current);
        current.clear();
      }
      i++;
    } else if (c == '\\') {
      // Backslash outside quotes: next character is literal
      i++;
      if (i < input.size()) {
        current += input[i];
        i++;
      }
    } else if (c == '$') {
      if (i + 1 < input.size() && input[i + 1] == '{') {
        size_t close = input.find('}', i + 2);
        if (close != std::string::npos) {
          std::string var_name = input.substr(i + 2, close - i - 2);
          current += getVariableValue(var_name);
          i = close + 1;
          continue;
        }
      }
      if (i + 1 < input.size() && (std::isalpha(input[i + 1]) || input[i + 1] == '_')) {
        size_t start = i + 1;
        size_t len = 1;
        while (start + len < input.size() && (std::isalnum(input[start + len]) || input[start + len] == '_')) {
          len++;
        }
        std::string var_name = input.substr(start, len);
        current += getVariableValue(var_name);
        i = start + len;
        continue;
      } else {
        current += c;
        i++;
      }
    } else {
      current += c;
      i++;
    }
  }
  if (!current.empty()) {
    tokens.push_back(current);
  }
  return tokens;
}

static std::string findExecutableInPath(const std::string &command) {
  if (command.find('/') != std::string::npos) {
    if (fs::exists(command) && fs::is_regular_file(command) && access(command.c_str(), X_OK) == 0) {
      return command;
    }
    return "";
  }

  const char *pathEnv = std::getenv("PATH");
  if (pathEnv == nullptr) {
    return "";
  }

  std::string path = pathEnv;
  size_t start = 0;
  while (start <= path.size()) {
    size_t end = path.find(':', start);
    std::string dir = (end == std::string::npos) ? path.substr(start) : path.substr(start, end - start);

    if (!dir.empty()) {
      fs::path candidate = fs::path(dir) / command;
      std::error_code ec;
      if (fs::exists(candidate, ec) && fs::is_regular_file(candidate, ec)) {
        if (access(candidate.c_str(), X_OK) == 0) {
          return candidate.string();
        }
      }
    }

    if (end == std::string::npos) {
      break;
    }
    start = end + 1;
  }

  return "";
}

struct Redirect {
  int fd = -1;          // 1 = stdout, 2 = stderr
  std::string file;
  bool append = false;
};

static void parseRedirects(std::vector<std::string> &tokens, std::vector<Redirect> &redirects) {
  std::vector<std::string> cleaned;
  for (size_t i = 0; i < tokens.size(); ++i) {
    if (tokens[i] == ">" || tokens[i] == "1>") {
      if (i + 1 < tokens.size()) {
        redirects.push_back({1, tokens[i + 1], false});
        i++;
      }
    } else if (tokens[i] == "2>") {
      if (i + 1 < tokens.size()) {
        redirects.push_back({2, tokens[i + 1], false});
        i++;
      }
    } else if (tokens[i] == ">>" || tokens[i] == "1>>") {
      if (i + 1 < tokens.size()) {
        redirects.push_back({1, tokens[i + 1], true});
        i++;
      }
    } else if (tokens[i] == "2>>") {
      if (i + 1 < tokens.size()) {
        redirects.push_back({2, tokens[i + 1], true});
        i++;
      }
    } else {
      cleaned.push_back(tokens[i]);
    }
  }
  tokens = cleaned;
}

static int openRedirect(const Redirect &r) {
  int flags = O_WRONLY | O_CREAT;
  flags |= r.append ? O_APPEND : O_TRUNC;
  return open(r.file.c_str(), flags, 0644);
}

static pid_t runExternalCommand(const std::vector<std::string> &tokens, const std::vector<Redirect> &redirects, bool in_background) {
  std::vector<char *> argv;
  argv.reserve(tokens.size() + 1);
  for (const auto &token : tokens) {
    argv.push_back(const_cast<char *>(token.c_str()));
  }
  argv.push_back(nullptr);

  pid_t pid = fork();
  if (pid == 0) {
    for (const auto &r : redirects) {
      int fd = openRedirect(r);
      if (fd >= 0) {
        dup2(fd, r.fd);
        close(fd);
      }
    }
    execvp(argv[0], argv.data());
    _exit(127);
  }

  if (!in_background) {
    int status = 0;
    waitpid(pid, &status, 0);
  }
  return pid;
}

char *command_generator(const char *text, int state) {
  static size_t list_index;
  static std::vector<std::string> matches;
  
  if (!state) {
    list_index = 0;
    matches.clear();
    std::string prefix(text);
    
    // Builtins
    std::vector<std::string> all_builtins = {"echo", "exit", "pwd", "cd", "type", "complete", "jobs", "history", "declare"};
    for (const auto &b : all_builtins) {
      if (b.compare(0, prefix.size(), prefix) == 0) {
        matches.push_back(b);
      }
    }
    
    // Executables in PATH
    const char *pathEnv = std::getenv("PATH");
    if (pathEnv != nullptr) {
      std::string path = pathEnv;
      size_t start = 0;
      while (start <= path.size()) {
        size_t end = path.find(':', start);
        std::string dir = (end == std::string::npos) ? path.substr(start) : path.substr(start, end - start);
        if (!dir.empty()) {
          std::error_code ec;
          if (fs::exists(dir, ec) && fs::is_directory(dir, ec)) {
            for (const auto &entry : fs::directory_iterator(dir, ec)) {
              std::string filename = entry.path().filename().string();
              if (filename.compare(0, prefix.size(), prefix) == 0) {
                if (fs::is_regular_file(entry.path(), ec)) {
                  if (access(entry.path().c_str(), X_OK) == 0) {
                    matches.push_back(filename);
                  }
                }
              }
            }
          }
        }
        if (end == std::string::npos) break;
        start = end + 1;
      }
    }
    
    // Sort and remove duplicates
    std::sort(matches.begin(), matches.end());
    matches.erase(std::unique(matches.begin(), matches.end()), matches.end());
  }
  
  if (list_index < matches.size()) {
    return strdup(matches[list_index++].c_str());
  }
  return nullptr;
}

struct Job {
  int job_id;
  pid_t pid;
  std::string command;
  std::string status;
};

static std::vector<Job> jobs_list;
static std::vector<std::string> shell_history;
static size_t last_appended_history_idx = 0;
static std::unordered_map<std::string, std::string> completions;

static std::string shellQuote(const std::string &str) {
  std::string result = "'";
  for (char c : str) {
    if (c == '\'') {
      result += "'\\''";
    } else {
      result += c;
    }
  }
  result += "'";
  return result;
}

static std::string getFirstWord(const std::string &line) {
  std::string word;
  size_t first_space = line.find_first_of(" \t");
  if (first_space != std::string::npos) {
    word = line.substr(0, first_space);
  } else {
    word = line;
  }
  if (word.size() >= 2 && ((word.front() == '\'' && word.back() == '\'') || (word.front() == '"' && word.back() == '"'))) {
    word = word.substr(1, word.size() - 2);
  }
  return word;
}

static std::string getPrevWord(const std::string &line, int start) {
  std::string prefix = line.substr(0, start);
  size_t last_non_space = prefix.find_last_not_of(" \t");
  if (last_non_space == std::string::npos) {
    return "";
  }
  prefix = prefix.substr(0, last_non_space + 1);
  size_t last_space = prefix.find_last_of(" \t");
  std::string prev_word;
  if (last_space == std::string::npos) {
    prev_word = prefix;
  } else {
    prev_word = prefix.substr(last_space + 1);
  }
  if (prev_word.size() >= 2 && ((prev_word.front() == '\'' && prev_word.back() == '\'') || (prev_word.front() == '"' && prev_word.back() == '"'))) {
    prev_word = prev_word.substr(1, prev_word.size() - 2);
  }
  return prev_word;
}

static std::vector<std::string> runCompleterScript(const std::string &script_path, const std::string &cmd, const std::string &word, const std::string &prev_word, const std::string &line_str, int cursor_pos) {
  std::vector<std::string> candidates;
  std::string run_cmd = "COMP_LINE=" + shellQuote(line_str) + " COMP_POINT=" + std::to_string(cursor_pos) + " " + shellQuote(script_path) + " " + shellQuote(cmd) + " " + shellQuote(word) + " " + shellQuote(prev_word);
  FILE *pipe = popen(run_cmd.c_str(), "r");
  if (!pipe) {
    return candidates;
  }
  char buffer[256];
  while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
    std::string line(buffer);
    if (!line.empty() && line.back() == '\n') {
      line.pop_back();
    }
    if (!line.empty()) {
      candidates.push_back(line);
    }
  }
  pclose(pipe);
  return candidates;
}

static std::vector<std::string> completer_candidates;
static size_t completer_index;

char *completer_generator(const char *text, int state) {
  if (!state) {
    completer_index = 0;
  }
  if (completer_index < completer_candidates.size()) {
    return strdup(completer_candidates[completer_index++].c_str());
  }
  return nullptr;
}

char **shell_completion(const char *text, int start, int end) {
  if (start == 0) {
    rl_attempted_completion_over = 1;
    return rl_completion_matches(text, command_generator);
  } else {
    std::string line_str(rl_line_buffer);
    std::string cmd = getFirstWord(line_str);
    auto it = completions.find(cmd);
    if (it != completions.end()) {
      rl_attempted_completion_over = 1;
      std::string word(text);
      std::string prev_word = getPrevWord(line_str, start);
      std::vector<std::string> raw_candidates = runCompleterScript(it->second, cmd, word, prev_word, line_str, rl_point);
      std::vector<std::string> filtered;
      for (const auto &c : raw_candidates) {
        if (c.compare(0, word.size(), word) == 0) {
          filtered.push_back(c);
        }
      }
      completer_candidates = filtered;
      return rl_completion_matches(text, completer_generator);
    }
  }
  return nullptr;
}

static void reapJobs(bool print_running) {
  if (jobs_list.empty()) {
    return;
  }

  // Update status of all jobs
  for (auto &job : jobs_list) {
    if (job.status == "Running") {
      int status = 0;
      pid_t res = waitpid(job.pid, &status, WNOHANG);
      if (res > 0) {
        job.status = "Done";
      }
    }
  }

  // Print jobs
  std::vector<Job> active_jobs;
  for (size_t i = 0; i < jobs_list.size(); ++i) {
    bool should_print = print_running || (jobs_list[i].status == "Done");
    if (should_print) {
      char marker = ' ';
      if (i == jobs_list.size() - 1) {
        marker = '+';
      } else if (i == jobs_list.size() - 2) {
        marker = '-';
      }
      std::string status_field = jobs_list[i].status;
      if (status_field.size() < 24) {
        status_field.append(24 - status_field.size(), ' ');
      }
      std::string cmd = jobs_list[i].command;
      if (jobs_list[i].status == "Running") {
        cmd += " &";
      }
      std::cout << "[" << jobs_list[i].job_id << "]" << marker << "  " << status_field << cmd << std::endl;
    }
    
    if (jobs_list[i].status == "Running") {
      active_jobs.push_back(jobs_list[i]);
    }
  }
  jobs_list = active_jobs;
}

static int getNextJobId() {
  if (jobs_list.empty()) {
    return 1;
  }
  int max_id = 0;
  for (const auto &job : jobs_list) {
    if (job.job_id > max_id) {
      max_id = job.job_id;
    }
  }
  return max_id + 1;
}

static bool isValidIdentifier(const std::string &name) {
  if (name.empty()) {
    return false;
  }
  if (!std::isalpha(name[0]) && name[0] != '_') {
    return false;
  }
  for (size_t i = 1; i < name.size(); ++i) {
    if (!std::isalnum(name[i]) && name[i] != '_') {
      return false;
    }
  }
  return true;
}

static bool isBuiltin(const std::string &cmd) {
  return cmd == "echo" || cmd == "exit" || cmd == "pwd" || cmd == "cd" || cmd == "type" || cmd == "complete" || cmd == "jobs" || cmd == "history" || cmd == "declare";
}

static void executeBuiltin(const std::vector<std::string> &tokens) {
  if (tokens[0] == "exit") {
    _exit(0);
  }
  if (tokens[0] == "echo") {
    std::string output;
    for (size_t i = 1; i < tokens.size(); ++i) {
      if (i > 1) {
        output += " ";
      }
      output += tokens[i];
    }
    std::cout << output << std::endl;
    return;
  }
  if (tokens[0] == "type") {
    std::string command = tokens.size() > 1 ? tokens[1] : "";
    if (command == "type" || command == "echo" || command == "exit" || command == "pwd" || command == "cd" || command == "complete" || command == "jobs" || command == "history" || command == "declare") {
      std::cout << command << " is a shell builtin" << std::endl;
    } else {
      std::string resolved = findExecutableInPath(command);
      if (!resolved.empty()) {
        std::cout << command << " is " << resolved << std::endl;
      } else {
        std::cout << command << ": not found" << std::endl;
      }
    }
    return;
  }
  if (tokens[0] == "pwd") {
    std::cout << fs::current_path().string() << std::endl;
    return;
  }
  if (tokens[0] == "cd") {
    if (tokens.size() > 1) {
      std::string target = tokens[1];
      if (target == "~") {
        const char *home = std::getenv("HOME");
        if (home) {
          target = home;
        }
      }
      std::error_code ec;
      fs::current_path(target, ec);
      if (ec) {
        std::cout << "cd: " << tokens[1] << ": No such file or directory" << std::endl;
      }
    }
    return;
  }
  if (tokens[0] == "complete") {
    if (tokens.size() > 2) {
      if (tokens[1] == "-p") {
        auto it = completions.find(tokens[2]);
        if (it != completions.end()) {
          std::cout << "complete -C '" << it->second << "' " << tokens[2] << std::endl;
        } else {
          std::cout << "complete: " << tokens[2] << ": no completion specification" << std::endl;
        }
      } else if (tokens[1] == "-C" && tokens.size() > 3) {
        completions[tokens[3]] = tokens[2];
      } else if (tokens[1] == "-r") {
        completions.erase(tokens[2]);
      }
    }
    return;
  }
  if (tokens[0] == "jobs") {
    reapJobs(true);
    return;
  }
  if (tokens[0] == "history") {
    if (tokens.size() > 2 && tokens[1] == "-r") {
      std::ifstream infile(tokens[2]);
      if (infile.is_open()) {
        std::string line;
        while (std::getline(infile, line)) {
          line = trim(line);
          if (!line.empty()) {
            shell_history.push_back(line);
            add_history(line.c_str());
          }
        }
      }
      last_appended_history_idx = shell_history.size();
      return;
    }
    if (tokens.size() > 2 && tokens[1] == "-w") {
      std::ofstream outfile(tokens[2]);
      if (outfile.is_open()) {
        for (const auto &line : shell_history) {
          outfile << line << "\n";
        }
      }
      return;
    }
    if (tokens.size() > 2 && tokens[1] == "-a") {
      std::ofstream outfile(tokens[2], std::ios_base::app);
      if (outfile.is_open()) {
        for (size_t i = last_appended_history_idx; i < shell_history.size(); ++i) {
          outfile << shell_history[i] << "\n";
        }
      }
      last_appended_history_idx = shell_history.size();
      return;
    }
    size_t limit = shell_history.size();
    if (tokens.size() > 1) {
      try {
        int val = std::stoi(tokens[1]);
        if (val > 0) {
          limit = (size_t)val;
        }
      } catch (...) {
        // ignore
      }
    }
    size_t start_idx = 0;
    if (shell_history.size() > limit) {
      start_idx = shell_history.size() - limit;
    }
    for (size_t i = start_idx; i < shell_history.size(); ++i) {
      printf("%5d  %s\n", (int)(i + 1), shell_history[i].c_str());
    }
    return;
  }
  if (tokens[0] == "declare") {
    if (tokens.size() > 2 && tokens[1] == "-p") {
      auto it = shell_variables.find(tokens[2]);
      if (it != shell_variables.end()) {
        std::cout << "declare -- " << it->first << "=\"" << it->second << "\"" << std::endl;
      } else {
        std::cout << "declare: " << tokens[2] << ": not found" << std::endl;
      }
    } else {
      for (size_t i = 1; i < tokens.size(); ++i) {
        size_t eq = tokens[i].find('=');
        if (eq != std::string::npos) {
          std::string name = tokens[i].substr(0, eq);
          std::string value = tokens[i].substr(eq + 1);
          if (isValidIdentifier(name)) {
            shell_variables[name] = value;
          } else {
            std::cout << "declare: `" << tokens[i] << "': not a valid identifier" << std::endl;
          }
        } else {
          if (!isValidIdentifier(tokens[i])) {
            std::cout << "declare: `" << tokens[i] << "': not a valid identifier" << std::endl;
          }
        }
      }
    }
    return;
  }
}

static std::vector<std::string> splitPipeline(const std::string &input) {
  std::vector<std::string> stages;
  std::string current;
  size_t i = 0;
  bool in_single_quote = false;
  bool in_double_quote = false;
  while (i < input.size()) {
    char c = input[i];
    if (c == '\'' && !in_double_quote) {
      in_single_quote = !in_single_quote;
      current += c;
      i++;
    } else if (c == '"' && !in_single_quote) {
      in_double_quote = !in_double_quote;
      current += c;
      i++;
    } else if (c == '\\' && !in_single_quote) {
      current += c;
      i++;
      if (i < input.size()) {
        current += input[i];
        i++;
      }
    } else if (c == '|' && !in_single_quote && !in_double_quote) {
      stages.push_back(current);
      current.clear();
      i++;
    } else {
      current += c;
      i++;
    }
  }
  stages.push_back(current);
  return stages;
}

static void runPipeline(const std::vector<std::string> &stages_raw, const std::string &original_input) {
  std::vector<std::vector<std::string>> parsed_stages;
  for (const auto &s : stages_raw) {
    auto t = splitCommand(trim(s));
    if (!t.empty()) {
      parsed_stages.push_back(t);
    }
  }

  if (parsed_stages.empty()) return;

  // Check background
  bool in_background = false;
  if (!parsed_stages.back().empty() && parsed_stages.back().back() == "&") {
    in_background = true;
    parsed_stages.back().pop_back();
  }

  size_t num_cmds = parsed_stages.size();
  std::vector<pid_t> pids(num_cmds);
  int prev_pipe_read = -1;

  for (size_t i = 0; i < num_cmds; ++i) {
    int cur_pipe[2];
    if (i < num_cmds - 1) {
      if (pipe(cur_pipe) < 0) {
        perror("pipe");
        return;
      }
    }

    pid_t pid = fork();
    if (pid == 0) {
      if (i > 0) {
        dup2(prev_pipe_read, 0);
        close(prev_pipe_read);
      }
      if (i < num_cmds - 1) {
        dup2(cur_pipe[1], 1);
        close(cur_pipe[0]);
        close(cur_pipe[1]);
      }

      std::vector<Redirect> redirects;
      parseRedirects(parsed_stages[i], redirects);
      for (const auto &r : redirects) {
        int fd = openRedirect(r);
        if (fd >= 0) {
          dup2(fd, r.fd);
          close(fd);
        }
      }

      if (isBuiltin(parsed_stages[i][0])) {
        executeBuiltin(parsed_stages[i]);
        _exit(0);
      }

      std::vector<char *> argv;
      argv.reserve(parsed_stages[i].size() + 1);
      for (const auto &token : parsed_stages[i]) {
        argv.push_back(const_cast<char *>(token.c_str()));
      }
      argv.push_back(nullptr);

      std::string resolved = findExecutableInPath(argv[0]);
      if (!resolved.empty()) {
        execvp(resolved.c_str(), argv.data());
      } else {
        std::cerr << argv[0] << ": not found" << std::endl;
      }
      _exit(127);
    }

    pids[i] = pid;
    if (i > 0) {
      close(prev_pipe_read);
    }
    if (i < num_cmds - 1) {
      close(cur_pipe[1]);
      prev_pipe_read = cur_pipe[0];
    }
  }

  if (!in_background) {
    for (pid_t pid : pids) {
      int status = 0;
      waitpid(pid, &status, 0);
    }
  } else {
    int job_id = getNextJobId();
    std::cout << "[" << job_id << "] " << pids.back() << std::endl;
    std::string cmd_str = original_input;
    if (!cmd_str.empty() && cmd_str.back() == '&') {
      cmd_str.pop_back();
      cmd_str = trim(cmd_str);
    }
    jobs_list.push_back({job_id, pids.back(), cmd_str, "Running"});
  }
}

static void saveHistoryOnExit() {
  const char *histfile = std::getenv("HISTFILE");
  if (histfile) {
    std::ofstream outfile(histfile, std::ios_base::app);
    if (outfile.is_open()) {
      for (size_t i = last_appended_history_idx; i < shell_history.size(); ++i) {
        outfile << shell_history[i] << "\n";
      }
    }
    last_appended_history_idx = shell_history.size();
  }
}

int main() {
  std::cout << std::unitbuf;
  std::cerr << std::unitbuf;

  rl_attempted_completion_function = shell_completion;

  const char *histfile = std::getenv("HISTFILE");
  if (histfile) {
    std::ifstream infile(histfile);
    if (infile.is_open()) {
      std::string line;
      while (std::getline(infile, line)) {
        line = trim(line);
        if (!line.empty()) {
          shell_history.push_back(line);
          add_history(line.c_str());
        }
      }
    }
    last_appended_history_idx = shell_history.size();
  }

  while (true) {
    reapJobs(false);
    char *line = readline("$ ");
    if (line == nullptr) {
      saveHistoryOnExit();
      break;
    }
    std::string input(line);
    free(line);
    
    input = trim(input);

    if (input.empty()) {
      continue;
    }

    add_history(input.c_str());
    shell_history.push_back(input);

    auto pipeline_stages = splitPipeline(input);
    if (pipeline_stages.size() > 1) {
      runPipeline(pipeline_stages, input);
      continue;
    }

    auto tokens = splitCommand(input);
    if (tokens.empty()) {
      continue;
    }

    // Parse redirects from tokens
    std::vector<Redirect> redirects;
    parseRedirects(tokens, redirects);

    // Setup redirects for builtins
    int saved_stdout = -1, saved_stderr = -1;
    for (const auto &r : redirects) {
      int fd = openRedirect(r);
      if (fd >= 0) {
        if (r.fd == 1) {
          saved_stdout = dup(1);
          dup2(fd, 1);
        } else if (r.fd == 2) {
          saved_stderr = dup(2);
          dup2(fd, 2);
        }
        close(fd);
      }
    }

    auto restoreRedirects = [&]() {
      if (saved_stdout >= 0) {
        dup2(saved_stdout, 1);
        close(saved_stdout);
      }
      if (saved_stderr >= 0) {
        dup2(saved_stderr, 2);
        close(saved_stderr);
      }
    };

    if (tokens[0] == "exit") {
      saveHistoryOnExit();
      return 0;
    }

    if (tokens[0] == "echo") {
      std::string output;
      for (size_t i = 1; i < tokens.size(); ++i) {
        if (i > 1) {
          output += " ";
        }
        output += tokens[i];
      }
      std::cout << output << std::endl;
      restoreRedirects();
      continue;
    }

    if (tokens[0] == "type") {
      std::string command = tokens.size() > 1 ? tokens[1] : "";
      if (command == "type" || command == "echo" || command == "exit" || command == "pwd" || command == "cd" || command == "complete" || command == "jobs" || command == "history" || command == "declare") {
        std::cout << command << " is a shell builtin" << std::endl;
      } else {
        std::string resolved = findExecutableInPath(command);
        if (!resolved.empty()) {
          std::cout << command << " is " << resolved << std::endl;
        } else {
          std::cout << command << ": not found" << std::endl;
        }
      }
      restoreRedirects();
      continue;
    }

    if (tokens[0] == "pwd") {
      std::cout << fs::current_path().string() << std::endl;
      restoreRedirects();
      continue;
    }

    if (tokens[0] == "cd") {
      if (tokens.size() > 1) {
        std::string target = tokens[1];
        if (target == "~") {
          const char *home = std::getenv("HOME");
          if (home) {
            target = home;
          }
        }
        std::error_code ec;
        fs::current_path(target, ec);
        if (ec) {
          std::cout << "cd: " << tokens[1] << ": No such file or directory" << std::endl;
        }
      }
      restoreRedirects();
      continue;
    }

    if (tokens[0] == "complete") {
      if (tokens.size() > 2) {
        if (tokens[1] == "-p") {
          auto it = completions.find(tokens[2]);
          if (it != completions.end()) {
            std::cout << "complete -C '" << it->second << "' " << tokens[2] << std::endl;
          } else {
            std::cout << "complete: " << tokens[2] << ": no completion specification" << std::endl;
          }
        } else if (tokens[1] == "-C" && tokens.size() > 3) {
          completions[tokens[3]] = tokens[2];
        } else if (tokens[1] == "-r") {
          completions.erase(tokens[2]);
        }
      }
      restoreRedirects();
      continue;
    }

    if (tokens[0] == "jobs") {
      reapJobs(true);
      restoreRedirects();
      continue;
    }

    if (tokens[0] == "history") {
      if (tokens.size() > 2 && tokens[1] == "-r") {
        std::ifstream infile(tokens[2]);
        if (infile.is_open()) {
          std::string line;
          while (std::getline(infile, line)) {
            line = trim(line);
            if (!line.empty()) {
              shell_history.push_back(line);
              add_history(line.c_str());
            }
          }
        }
        last_appended_history_idx = shell_history.size();
        restoreRedirects();
        continue;
      }
      if (tokens.size() > 2 && tokens[1] == "-w") {
        std::ofstream outfile(tokens[2]);
        if (outfile.is_open()) {
          for (const auto &line : shell_history) {
            outfile << line << "\n";
          }
        }
        restoreRedirects();
        continue;
      }
      if (tokens.size() > 2 && tokens[1] == "-a") {
        std::ofstream outfile(tokens[2], std::ios_base::app);
        if (outfile.is_open()) {
          for (size_t i = last_appended_history_idx; i < shell_history.size(); ++i) {
            outfile << shell_history[i] << "\n";
          }
        }
        last_appended_history_idx = shell_history.size();
        restoreRedirects();
        continue;
      }
      size_t limit = shell_history.size();
      if (tokens.size() > 1) {
        try {
          int val = std::stoi(tokens[1]);
          if (val > 0) {
            limit = (size_t)val;
          }
        } catch (...) {
          // ignore
        }
      }
      size_t start_idx = 0;
      if (shell_history.size() > limit) {
        start_idx = shell_history.size() - limit;
      }
      for (size_t i = start_idx; i < shell_history.size(); ++i) {
        printf("%5d  %s\n", (int)(i + 1), shell_history[i].c_str());
      }
      restoreRedirects();
      continue;
    }

    if (tokens[0] == "declare") {
      if (tokens.size() > 2 && tokens[1] == "-p") {
        auto it = shell_variables.find(tokens[2]);
        if (it != shell_variables.end()) {
          std::cout << "declare -- " << it->first << "=\"" << it->second << "\"" << std::endl;
        } else {
          std::cout << "declare: " << tokens[2] << ": not found" << std::endl;
        }
      } else {
        for (size_t i = 1; i < tokens.size(); ++i) {
          size_t eq = tokens[i].find('=');
          if (eq != std::string::npos) {
            std::string name = tokens[i].substr(0, eq);
            std::string value = tokens[i].substr(eq + 1);
            if (isValidIdentifier(name)) {
              shell_variables[name] = value;
            } else {
              std::cout << "declare: `" << tokens[i] << "': not a valid identifier" << std::endl;
            }
          } else {
            if (!isValidIdentifier(tokens[i])) {
              std::cout << "declare: `" << tokens[i] << "': not a valid identifier" << std::endl;
            }
          }
        }
      }
      restoreRedirects();
      continue;
    }

    // Check if the command should run in the background
    bool in_background = false;
    if (!tokens.empty() && tokens.back() == "&") {
      in_background = true;
      tokens.pop_back();
    }

    // Restore redirects before running external command (it handles its own)
    restoreRedirects();

    std::string resolved = findExecutableInPath(tokens[0]);
    if (!resolved.empty()) {
      pid_t pid = runExternalCommand(tokens, redirects, in_background);
      if (in_background) {
        int job_id = getNextJobId();
        std::cout << "[" << job_id << "] " << pid << std::endl;
        std::string cmd_str = input;
        if (!cmd_str.empty() && cmd_str.back() == '&') {
          cmd_str.pop_back();
          cmd_str = trim(cmd_str);
        }
        jobs_list.push_back({job_id, pid, cmd_str, "Running"});
      }
    } else {
      std::cout << tokens[0] << ": not found" << std::endl;
    }
  }
}
