# CodeCrafters Automated Workflow Solution

This repository contains the complete C++ implementation for the **Build Your Own Shell** challenge on CodeCrafters, along with a reusable **Python + Playwright automation script** (`cc_auto.py`) to fully automate the task fetching, testing/submission, and UI stage completion workflow.

---

## 🚀 Features & Automation Workflow

The included `cc_auto.py` script automates the complete cycle:
1. **`python3 cc_auto.py task`**: Fetches the current stage instructions directly from the CodeCrafters CLI.
2. **`python3 cc_auto.py submit`**: Runs `codecrafters submit` to run remote tests on CodeCrafters' servers.
3. **`python3 cc_auto.py mark <slug>`**: Uses headless Chromium via Playwright to log into CodeCrafters and automatically click the **"Mark stage as complete"** button once tests pass.
4. **`python3 cc_auto.py cycle <slug>`**: Combines submission, test verification, and automated web clicking into a single command.

---

## 🛠️ Setup Instructions

### Prerequisites
- **Python 3.9+** installed
- **CodeCrafters CLI** installed and logged in (`codecrafters login`)
- **C++ Compiler** (`g++` / `clang++` / `MSVC`) supporting C++17 or C++23 with `readline` support (or `vcpkg` for CMake builds).

### 1. Install Python Dependencies
```bash
pip install playwright
playwright install chromium
```

### 2. Configure Credentials in `cc_auto.py`
Open `cc_auto.py` (or rename `cc_auto_template.py` to `cc_auto.py`) and fill in your CodeCrafters web session tokens:
```python
SESSION_TOKEN = "your_cc-frontend:session_token_v1"
USER_ID       = "your_user_id"
USERNAME      = "your_username"
COURSE        = "shell"
```

> **How to find your session tokens:**
> 1. Log in to [CodeCrafters](https://app.codecrafters.io) in your browser.
> 2. Open Developer Tools (`F12` or `Cmd+Option+I`).
> 3. Go to **Application** -> **Local Storage** -> `https://app.codecrafters.io`.
> 4. Copy the values for `cc-frontend:session_token_v1`, `cc-frontend:current_user_cache_v1:user_id`, and `cc-frontend:current_user_cache_v1:username`.

---

## 💻 Running & Testing

### Local Compilation & Testing
To build and run locally using GCC/Clang (Linux/macOS/Git Bash on Windows):
```bash
g++ -std=c++17 -O3 src/main.cpp -o main_test -lreadline
./main_test
```

Using CMake (Cross-platform / Windows PowerShell / Visual Studio):
```bash
cmake -B build -S .
cmake --build ./build
./build/shell
```

### Automated CodeCrafters Workflow
```bash
# 1. View current stage task
python3 cc_auto.py task

# 2. Automatically submit code and mark stage complete upon passing
python3 cc_auto.py cycle <stage_slug>
```

---

## 💻 Cross-Platform (Windows, macOS, Linux) Notes
- `cc_auto.py` uses standard Python `subprocess` and `playwright`, making it fully compatible with Windows PowerShell, Command Prompt, WSL, macOS, and Linux.
- On Windows, ensure `codecrafters.exe` and `python` are in your PATH.
